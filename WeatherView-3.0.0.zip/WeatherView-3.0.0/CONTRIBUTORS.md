# WeatherView Contributors

- [Matteo Battilana](https://github.com/MatteoBattilana) (2016 - present)
  - Initial developer
  - Created sample app
  - Added orientation sensor support
  - Created graphics
- [Mitchell Skaggs](https://github.com/magneticflux-) (2017 - present)
  - Large overhaul of the project
  - More advanced particle system
  - Added Kotlin language support

View all contributors [here](https://github.com/MatteoBattilana/WeatherView/graphs/contributors).